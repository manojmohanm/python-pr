
#Client.py_code

import pickle
import getpass


def fun(name, password):
    s = {"username": name, "password": password}
    safecode = pickle.dumps(s)
    with open("users.json", "wb") as f:
        f.write(safecode)
        f.close()
    return safecode


if __name__ == '__main__':
    u = input("Username : ")
    p = getpass.getpass("Password: ")
    yo_fun = fun(u, p)
